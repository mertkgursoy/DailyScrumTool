 <html> 
  <head>
            <title>Daily Scrum Tool</title>
            <meta name="author" content="MertKGursoy">
            <script> 
                console.log("author: Mert Kadir Gürsoy");
            </script>
            <link rel="stylesheet" type="text/css" href="asset/main.css">
            
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            


    </head>
    <body>



