
   
<?php 
 // Header
 header("Location: login.php");
?>